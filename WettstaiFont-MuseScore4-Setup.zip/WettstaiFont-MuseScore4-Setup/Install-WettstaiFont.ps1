# =====================================================================
#  Install-WettstaiFont.ps1
#  Installiert WettstaiFont fuer MuseScore 4 (Windows 10/11)
#
#  Was dieses Skript macht:
#   1. Installiert WettstaiFont.otf als Windows-Schriftart (fuer den
#      aktuellen Benutzer, kein Admin noetig)
#   2. Kopiert WettstaiFont.json + WettstaiFont.otf in den MuseScore-
#      MusicFonts-Ordner (Documents\MuseScore4\MusicFonts\WettstaiFont)
#   3. Kopiert die SMuFL-Metadaten in den SMuFL-Standardpfad
#      (%LOCALAPPDATA%\SMuFL\Fonts\WettstaiFont) - damit auch andere
#      SMuFL-faehige Programme die Schrift erkennen.
#
#  Bedienung:
#   Rechtsklick auf diese Datei -> "Mit PowerShell ausfuehren"
#   ODER in PowerShell:
#       Set-ExecutionPolicy -Scope Process Bypass
#       .\Install-WettstaiFont.ps1
# =====================================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host " WettstaiFont Installation fuer MuseScore 4"   -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""

# Quellverzeichnis = Ordner dieses Skripts
$srcDir = $PSScriptRoot
$otfFile  = Join-Path $srcDir "WettstaiFont.otf"
$jsonFile = Join-Path $srcDir "WettstaiFont.json"
$glyphFile = Join-Path $srcDir "glyphnames.json"

# Pruefen ob Quellen vorhanden sind
foreach ($f in @($otfFile, $jsonFile)) {
    if (-not (Test-Path $f)) {
        Write-Host "FEHLER: Datei nicht gefunden: $f" -ForegroundColor Red
        Write-Host "Bitte stelle sicher, dass alle Dateien im selben Ordner wie dieses Skript liegen." -ForegroundColor Red
        Read-Host "Druecke Enter zum Beenden"
        exit 1
    }
}

# ----- Schritt 1: Schrift fuer aktuellen Benutzer installieren -----
Write-Host "[1/3] Installiere WettstaiFont.otf als Windows-Schriftart..." -ForegroundColor Yellow

$userFontDir = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Fonts"
if (-not (Test-Path $userFontDir)) {
    New-Item -ItemType Directory -Path $userFontDir -Force | Out-Null
}

$userFontTarget = Join-Path $userFontDir "WettstaiFont.otf"
Copy-Item -Path $otfFile -Destination $userFontTarget -Force

# In Registry eintragen (User-Scope, kein Admin noetig)
$regPath = "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"
if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}
Set-ItemProperty -Path $regPath -Name "WettstaiFont (OpenType)" -Value $userFontTarget -Type String -Force
Write-Host "   OK - Schriftart installiert (User-Scope)." -ForegroundColor Green

# ----- Schritt 2: MuseScore MusicFonts-Ordner -----
Write-Host "[2/3] Installiere SMuFL-Metadaten in MuseScore MusicFonts..." -ForegroundColor Yellow

$musicFontsDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) "MuseScore4\MusicFonts\WettstaiFont"
if (-not (Test-Path $musicFontsDir)) {
    New-Item -ItemType Directory -Path $musicFontsDir -Force | Out-Null
}

Copy-Item -Path $otfFile  -Destination (Join-Path $musicFontsDir "WettstaiFont.otf")  -Force
Copy-Item -Path $jsonFile -Destination (Join-Path $musicFontsDir "WettstaiFont.json") -Force
# Auch unter dem alternativen Namen "metadata.json" ablegen
# (manche MuseScore-Versionen suchen exakt diesen Namen)
Copy-Item -Path $jsonFile -Destination (Join-Path $musicFontsDir "metadata.json") -Force

if (Test-Path $glyphFile) {
    Copy-Item -Path $glyphFile -Destination (Join-Path $musicFontsDir "glyphnames.json") -Force
}

Write-Host "   OK -> $musicFontsDir" -ForegroundColor Green

# ----- Schritt 3: SMuFL-Standardpfad (fuer andere Software) -----
Write-Host "[3/3] Installiere SMuFL-Standardpfad..." -ForegroundColor Yellow

$smuflDir = Join-Path $env:LOCALAPPDATA "SMuFL\Fonts\WettstaiFont"
if (-not (Test-Path $smuflDir)) {
    New-Item -ItemType Directory -Path $smuflDir -Force | Out-Null
}
# SMuFL-Spec: <fontname>.json muss hier liegen
Copy-Item -Path $jsonFile -Destination (Join-Path $smuflDir "WettstaiFont.json") -Force
if (Test-Path $glyphFile) {
    Copy-Item -Path $glyphFile -Destination (Join-Path $smuflDir "glyphnames.json") -Force
}
Write-Host "   OK -> $smuflDir" -ForegroundColor Green

Write-Host ""
Write-Host "==============================================" -ForegroundColor Green
Write-Host " Installation abgeschlossen!"                   -ForegroundColor Green
Write-Host "==============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Naechste Schritte:" -ForegroundColor Cyan
Write-Host "  1. Schliesse MuseScore 4 KOMPLETT (auch aus dem Tray)."
Write-Host "  2. Starte MuseScore 4 neu."
Write-Host "  3. Format -> Style... -> Score"
Write-Host "     -> 'WettstaiFont' sollte jetzt in der Schrift-Auswahl"
Write-Host "        erscheinen."
Write-Host ""
Write-Host "  Zum Einfuegen einzelner Wettstai-Symbole:"
Write-Host "  Ansicht -> Master-Palette (Umschalt+F9) -> Symbole"
Write-Host "  Dort die Schriftart 'WettstaiFont' waehlen."
Write-Host ""
Write-Host "WICHTIG: Funktioniert vollstaendig erst ab MuseScore 4.6!" -ForegroundColor Yellow
Write-Host "Pruefe deine Version unter: Hilfe -> Ueber MuseScore" -ForegroundColor Yellow
Write-Host ""
Read-Host "Druecke Enter zum Beenden"
