# =====================================================================
#  Uninstall-WettstaiFont.ps1
#  Entfernt WettstaiFont aus Windows und MuseScore 4 wieder.
# =====================================================================

$ErrorActionPreference = "SilentlyContinue"

Write-Host ""
Write-Host "Deinstalliere WettstaiFont..." -ForegroundColor Yellow

# 1. Schrift aus User-Schriften entfernen
$userFontFile = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Fonts\WettstaiFont.otf"
Remove-Item $userFontFile -Force
Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts" -Name "WettstaiFont (OpenType)" -Force

# 2. MuseScore-MusicFonts
$musicFontsDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) "MuseScore4\MusicFonts\WettstaiFont"
Remove-Item $musicFontsDir -Recurse -Force

# 3. SMuFL-Standardpfad
$smuflDir = Join-Path $env:LOCALAPPDATA "SMuFL\Fonts\WettstaiFont"
Remove-Item $smuflDir -Recurse -Force

Write-Host "Fertig. Bitte MuseScore 4 neu starten." -ForegroundColor Green
Read-Host "Druecke Enter zum Beenden"
